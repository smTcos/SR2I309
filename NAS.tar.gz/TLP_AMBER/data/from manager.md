# qsdsddqsdsqdqsdMeeting notes

* 📅 15 January 2021, via Nextcloud Talk
* 👥 Julius, Vanessa, Jan, …

## Tasks ✅dfsfsdf

* [ ] Finish marketing campaign
* [ ] To do 2
* [ ] …qsdqsd

## Agenda 📑

* What we want to change
* …

## Recap from last meeting 🔁

* …

## Discussion 💬

* Vanessa suggested …
* Julius brought up …
* …